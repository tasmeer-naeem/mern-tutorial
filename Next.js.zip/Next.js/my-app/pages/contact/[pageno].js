import React from 'react'
import {useRouter} from 'next/router'
import Navbar from '../../components/Navbar';

export const getStaticPaths  = async()=>{
    const url = "https://jsonplaceholder.typicode.com/posts"
    const res = await fetch(url)
    const data = await res.json()

    const paths = data.map((item) => { 
    return{
        params:{
            pageno : item.id.toString()
            }
         }
    })

    return{
       paths,
       fallback:false
    }
} 

export const getStaticProps = async(context)=>{
    const id = context.params.pageno
    const url = `https://jsonplaceholder.typicode.com/posts/${id}`
    const res = await fetch(url) 
    const data = await res.json()
  
    return{
      props:{
        data   // dataa : data
      }
    }
  
}


const pageno = ({data}) => {
    const router = useRouter();
    const pagenum = router.query.pageno 
    return (
        <div>
        <Navbar/>
        <h2>dynamiic routing {pagenum}</h2>   
        <h3 key={data.id} ></h3>
        <h3>{data.id}</h3>
        <h3>{data.title}</h3>
        <h3>{data.body}</h3>
        </div>
    )
}

export default pageno
