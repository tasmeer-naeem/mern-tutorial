import Link from 'next/link'
import React from 'react'
import Navbar from '../../components/Navbar'

export const getStaticProps = async()=>{
  const url = "https://jsonplaceholder.typicode.com/posts"
  const res = await fetch(url) 
  const data = await res.json()

  return{
    props:{
      data   // dataa : data
    }
  }

}

const index = ({data}) => {   //({dataa})
    return (
        <div>
        <Navbar/>
          <h2 className='heading' >contact page</h2>  
          {
            data.slice(0,10).map((item)=>{       //0-10 means 9 items
              return(
                <div key={item.id} >
                <h4>{item.id}</h4> 
              <Link href={`/contact/${item.id}`} ><a><h4>{item.title}</h4></a></Link> 
                </div>
              )
            })
          }
        </div>
    )
}

export default index
