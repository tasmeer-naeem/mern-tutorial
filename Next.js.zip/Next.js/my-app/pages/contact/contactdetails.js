import React from 'react'
import Navbar from '../../components/Navbar'

const contactdetails = () => {
    return (
        <div>
        <Navbar/>
      <h2 className='heading'> contact details page</h2> 
        </div>
    )
}

export default contactdetails
