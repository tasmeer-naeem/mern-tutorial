import Link from 'next/link'
import { useRouter } from 'next/router'
import React from 'react'
import { useEffect } from 'react'
 



const error = () => {
    const router  = useRouter();

    const handleInput=()=>{
        router.push("/contact")
    }

    useEffect(() => {
        setTimeout(() => {
        router.push("/")
        }, 3000);
    }, [])

    return (
        <div>
        <style jsx>
        {` 
            h1{
                color:grey;
            }
            h3{
                color:pink;
            }
        `}
        </style>
            <h1>404 error found</h1>
            <h3>Page is not avaialable</h3>
            <Link href="/"><a>Back To Index page</a></Link><br/>
            <span onClick={handleInput} > <a>Go to Contact page</a></span>
        </div>
    )
}

export default error
