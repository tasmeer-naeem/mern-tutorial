import React from 'react'
import Link from 'next/link'
import Image from 'next/image'
import Navbar from '../components/Navbar'
import styles from '../styles/index.module.css'


const index = () => {
  return (
    <div>
    <Navbar/>
    <h2 className={styles.heading} >Index page</h2>
    <Image src="/img.jpg" width="500" height="300" alt='indeximg'/>
    </div>
  )
}

export default index
