import React from 'react'
import Navbar from '../components/Navbar'
import styles from '../styles/about.module.css'
import Head from 'next/head'

const about = () => {
    return (
        <div>
        <Head>
        <title>About Page</title>
        </Head>
        <Navbar/>
         <h2 className={styles.heading} >about page</h2>   
        </div>
    )
}

export default about
