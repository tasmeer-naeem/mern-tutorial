import React from 'react'
import Link from 'next/link'

const Navbar = () => {
    return (
        <div>
        <Link href='/'><a>INDEX</a></Link><br/>
        <Link href='/home'><a>HOME</a></Link><br/>
        <Link href='/about'><a>ABOUT</a></Link><br/>
        <Link href='/contact'><a>CONTACT</a></Link><br/> 
        <Link href='/contact/contactdetails'><a>CONTACT DETAILS</a></Link><br/> 
        </div>
    )
}

export default Navbar
