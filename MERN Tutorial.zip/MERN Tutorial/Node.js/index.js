//console.log("Welcome to node course ")

//SYNCHRONOUS FORMAT

const fs = require("fs")
//fs.writeFileSync("newfile.txt","created new file")
//fs.writeFileSync("newfile.txt","writeFileSync , created new file  <br>")
//fs.writeFileSync("newfile.txt","checking")
//fs.appendFileSync("newfile.txt","  used appendFileSync")
const buf_data=fs.readFileSync("newfile.txt")
const read_data=buf_data.toString()
console.log(read_data)
//console.log(buf_data)
//<Buffer 77 72 69 74 65 46 69 6c 65 53 79 6e 63 20 2c 20 63 72 65 61 74 65 64 20 6e 65 77 20 66 69 6c 65 20 20 3c 62 72 3e 20 20 75 73 65 64 20 61 70 70 65 6e ... 9 more bytes>
