//ASYNCHRONOUS FORMAT

const fs=require("fs")
// fs.writeFile("newfile2.txt","Asynchronous function" , (err)=>{
//     console.log("file is created")
//     console.log(err)
// })

// fs.appendFile("newfile2.txt"," append file async method" ,(err)=>{
//     console.log("task completed")
//     console.log(err)
// })

//checking which cmd is running early sync or async is best method

// const data=fs.readFileSync("newfile2.txt" ,"utf8")
// console.log(data)
// console.log("after the data")

// fs.readFile("newfile2.txt" ,"utf8", (err,data)=>{
//     console.log(data)
//     console.log(err)
// })
// console.log("after the data") 