//const importt = require('./practice')
//console.log(importt.exportadd(10,5))
//console.log(importt.exportsub(10,5))

// const {exportadd,exportsub}=require("./practice")
// console.log(exportadd(20,30))
// console.log(exportsub(30,10))

