const calc = require("./home")

// console.log(calc)
// console.log(calc.add(5,5));
// console.log(calc.sub(10,5));

const {add,sub} = require("./home")

console.log(add(5,5));
console.log(sub(10,5));