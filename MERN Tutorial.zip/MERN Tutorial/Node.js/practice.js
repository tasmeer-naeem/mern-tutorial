//const fs=require("fs")


//ASYNC
// fs.writeFile("practice.txt","practice file",(err)=>{
//     console.log("file created")
// })
// fs.readFile("practice.txt","utf8",(err,data)=>{
//     console.log(data)
// })
// fs.appendFile("practice.txt"," append more text",(err)=>{
//     console.log("text appended")
// })
// fs.mkdir("practicefolder",(err)=>{
//     console.log("folder created")
// })
// fs.unlink("practice.txt",(err)=>{
//     console.log("practice file deleted")
// })
// fs.rmdir("practicefolder",(err)=>{
//     console.log("practice folder deleted")
// })

//SYNC
// const writefile=fs.writeFileSync("practice2.txt","practice2 file")
// console.log(writefile)
// const readfile=fs.readFileSync("practice2.txt","utf8")
// console.log(readfile)
// const appendtext=fs.appendFileSync("practice2.txt"," append text")
// console.log(appendtext)
//const folder=fs.mkdirSync("practicefolder/practice2folder")
//console.log("folder 2 created")
// const delfile=fs.unlinkSync("practice2.txt")
// console.log("practice 2 file deleted")
// console.log(delfile)
// const delfolder=fs.rmdirSync("practicefolder/practice2folder")
// console.log("practice 2 folder deleted")
// console.log(delfolder)

//IMPORT EXPORT
// const exportadd=(a,b)=>{
//     return (a + b )
// };
// const exportsub=(a,b)=>{
//     return (a - b )
// };
// //module.exports.exportadd=exportadd
// //module.exports.exportsub=exportsub
// module.exports={exportadd,exportsub}

//WRAPPER FUNCTION
// (function(exports,require,module,__dirname,__filename){
//         const name="wrapper fuunction"
//         console.log(name)
// })();
//console.log("wrapper fuunction")

//JSON 
//const fs=require("fs")
// const objdata={
//     name:"Tasmeer",
//     age:18
// }
// console.log(objdata)
// const jsondata=JSON.stringify(objdata)
// console.log(jsondata)
// const realdata=JSON.parse(jsondata)
// console.log(realdata)

//HTTP MODULE
// const http=require("http")
// const server=http.createServer((req,res)=>{
//     if(req.url == "/"){
//         res.writeHead(200,({"content-type":"text/html"}))  // "content-type"="application/json"
//         res.end("<h1> HOME PAGE <h1>")
//     }
//     else{
//         res.writeHead(404,({"content-type":"text/html"}))
//         res.end("<h1> 404 error ! page not found <h1>")
//     }
// })
// server.listen(100,"127.0.0.1",()=>{
//     console.log("server is running on 100")
// })

//EVENTS
// const EventEmitter=require("events")
// const event=new EventEmitter()
// event.on("request",(sc,msg)=>{
//     console.log(`the page is ${sc} ${msg}`)
// })
// event.on("request",()=>{
//     console.log({name:"tasmeer"})
// })
// event.emit("request",200,"ok")

//BUFFERANDSTREAM
// const http=require("http")
// const server=http.createServer()
// const port=200
// const fs=require("fs")
// // server.on("request",(req,res)=>{
// //     const rstream=fs.createReadStream("streamandbuffer.txt")
// //     rstream.on("data",(filedata)=>{
// //         res.end(filedata)
// //     })
// //     rstream.on("end",()=>{
// //         res.end()
// //     })
// //     rstream.on("error",(err)=>{
// //         console.log(err)
// //         res.end("page not found")
// //     })
// // })
// server.on("request",(req,res)=>{
//     const rstream=fs.createReadStream("streamandbuffer.txt")
//     rstream.pipe(res)
// })
// server.listen(port,"127.0.0.1",()=>{
//     console.log("server is running on 200")
// })