const fs=require("fs")

// fs.mkdir("newfolder",(err)=>{
//     console.log("folder created")
//     console.log(err)
// })

// fs.writeFile("newfolder/newfile.txt","created async file" ,(err)=>{
//     console.log("file created")
//     console.log(err)
// })

// fs.appendFile("newfolder/newfile.txt"," append method" , (err)=>{
//     console.log("file updated")
//     console.log(err)
// })

// fs.readFile("newfolder/newfile.txt","utf8",(err,data)=>{
//     console.log(data)
//     console.log(err)
// })

// fs.rename("newfolder/newfile.txt","newfolder/updatedfile.txt",(err)=>{
//     console.log("file renamed")
//     console.log(err)
// })

// fs.unLink("newfolder/newfile.txt",(err)=>{
//     console.log("file deleted")
//     console.log(err)
// })

// fs.rmdir("newfolder",(err)=>{
//     console.log("folder deleted")
//     console.log(err)
// })