const fs=require("fs")
const http=require("http")
const server=http.createServer()

// server.on("request",(req,res)=>{
//     fs.readFile("streamandbuffer.txt","utf8",(err,data)=>{
//         if(err){
//             return console.log(err)
//         }
//         else{
//             res.end(data)
//         }
//     })
// })


// server.on("request",(req,res)=>{
// const rstream=fs.createReadStream("streamandbuffer.txt");
// rstream.on("data",(chunkdata)=>{
//     res.write(chunkdata)
// })
// rstream.on("end",()=>{
//     res.end()
// })
// rstream.on("error",(err)=>{
//     console.log(err)
//     res.end("page not found")
// })
// })

server.on("request",(req,res)=>{
    const rstraem=fs.createReadStream("streamandbuffer.txt")
    rstraem.pipe(res)
})
server.listen(1000,"127.0.0.1",(err)=>{
        console.log("server is running on 1000 port")
})