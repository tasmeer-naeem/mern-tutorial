const EventEmitter=require("events")
const event=new EventEmitter()

// event.on("my name",()=>{
//     console.log("Tasmeer")
// })
// event.on("my name",()=>{
//     console.log("BSCS")
// })
// event.emit("my name")

event.on("checkpage",(sc,msg)=>{         //sc statuscode
    console.log(`status code is ${sc} and the page is ${msg}`)
})

event.emit("checkpage",200,"ok")