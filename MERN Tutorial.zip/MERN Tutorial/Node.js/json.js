const fs=require("fs")

const data={
    name:"tasmeer",
    age:18
}
 //console.log(data)
 //console.log(data.name)

const jsonformat=JSON.stringify(data)
// console.log(jsonformat)
// fs.writeFile("jsonfile.json",jsonformat,(err)=>{
//     console.log("created file")
// });

// const objformat=JSON.parse(jsonformat)
// console.log(objformat)

// fs.readFile("jsonfile.json",(err)=>{
//     console.log(jsonformat)
//     console.log(objformat)
// })

fs.readFile("jsonfile.json","utf8",(err,mydata)=>{
    const realdata=JSON.parse(mydata)
    console.log(mydata)
    console.log(realdata)
})


