const http=require("http")
const fs=require("fs")

// fs.readFile("jsonapi.json","utf8",(err,data)=>{
//     //console.log(data)
//     //res.end(data[2])
//     const realdata=JSON.parse(data)
//     res.end(realdata[2].body)  
//     })

const server=http.createServer((req,res)=>{
    const jsondata=fs.readFileSync("jsonapi.json","utf8")
    const objdata=JSON.parse(jsondata)
    

    if(req.url == "/"){
        res.end("hello our own web server home page")
    }else if(req.url == "/AboutUs"){
    res.end("hello our own web server about page")
    }else if(req.url == "/Contact"){
        res.end("hello our own web server contact page")
    }else if(req.url == "/jsonapi"){
        res.writeHead(200,({"Content-type":"application/json"}))
        res.end(jsondata)
       //res.end(objdata[3].body)
    }else{
        res.writeHead(404,({"Content-type":"text/html"}))
        res.end("<h1> 404 error  ! Page not found </h1>")
    }
})
server.listen(2000,"127.0.0.1",()=>{
    console.log("server is running on 2000")
})