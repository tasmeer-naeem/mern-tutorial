(function(exports,require,module,__filename,__dirname){
   // const fss = require("fs")
    const name="tasmeer "
    console.log(name)
   // module.exports={functionn}
})();

