const express=require("express")
const path=require("path")
const hbs=require("hbs")
const app=express()
const port=8000

//const staticpath=path.join(__dirname,"../public")
//console.log(staticpath)
//app.use(express.static(staticpath))

const viewpath=path.join(__dirname,"../templates/views")
const partialpath=path.join(__dirname,"../templates/partials")
app.set("views",viewpath)
app.set("view engine","hbs")
hbs.registerPartials(partialpath)

app.get("/",(req,res)=>{
    res.render("index" , {
        myname:"template engine (make dynamic data)"
    })
})

app.get("/",(req,res)=>{
    res.send("<h1> HOME PAGE </h1>")
})
app.get("/about",(req,res)=>{
    res.render("about")
})
app.get("/contact",(req,res)=>{
    res.status(200).send("CONTACT PAGE")
})
app.get("/temp",(req,res)=>{
   // res.send("TEMP PAGE")
   res.send([             //res.json({})
       {
       id:1,
       name:"tasmeer"
        },
        {
        id:2,
        name:"express.js"
        }
        ])
})
app.get("/about/*",(req,res)=>{
    res.render("error404",{
        errorcomment:"404 error found go back "
    })
})
app.get("*",(req,res)=>{
    res.render("error404",{
        errorcomment:"404 error ! Page not found"
    })
})

app.listen(port,()=>{
    console.log(`server is running on ${port}`)
})

//api.openweathermap.org/data/2.5/weather?q={city name}&appid={API key}