const express=require("express")
const app=express()
const port=7000
const path=require("path")
const hbs=require("hbs")

// const staticpath=path.join(__dirname,"../public")
// console.log(staticpath)
// app.use(express.static(staticpath))

const viewpath=path.join(__dirname,"../templates/views")
//console.log(viewpath)
app.set("views",viewpath)
app.set("view engine","hbs")

const partialpath=path.join(__dirname,"../templates/partials")
//console.log(partialpath)
hbs.registerPartials(partialpath)

app.get("/",(req,res)=>{     //index.hbs
    res.render("index",{
        myname:"passed props"
    })
})
app.get("/about",(req,res)=>{    //about.hbs
    res.render("about")
})
app.get("/",(req,res)=>{    //index.html
    res.render("index")
})
app.get("/",(req,res)=>{                 
    res.send("<h1>HOME PAGE</h1>")
})
app.get("/about/*",(req,res)=>{    //error.hbs
    res.render("error404",{
        errorcomment:"404 error found ! go back to previous page"
    })
})
app.get("*",(req,res)=>{    //error.hbs
    res.render("error404",{
        errorcomment:"404 error found ! page is not available"
    })
})
app.listen(port,"127.0.0.1",(err)=>{
    console.log(`server is running on ${port} ..`)
})